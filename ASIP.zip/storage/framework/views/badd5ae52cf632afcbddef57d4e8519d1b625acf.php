<footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2018 <div class="bullet"></div> Design By <a href="https://nauval.in/">Muhamad Nauval Azhar </a>Modded By <a href="https://ariikun.surge.sh">Ari Farhan</a>
        </div>
        <div class="footer-right">
          
        </div>
      </footer><?php /**PATH D:\PROJEK\ASIP\resources\views/components/dcore/footer.blade.php ENDPATH**/ ?>