<div class="simple-footer">
              Copyright &copy; Stisla 2018
            </div><?php /**PATH D:\PROJEK\ASIP\resources\views/components/footer.blade.php ENDPATH**/ ?>