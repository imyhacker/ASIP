
    <!-- General JS Scripts -->
    <script src="https://demo.getstisla.com/assets/modules/jquery.min.js"></script>
    <script src="https://demo.getstisla.com/assets/modules/popper.js"></script>
    <script src="https://demo.getstisla.com/assets/modules/tooltip.js"></script>
    <script src="https://demo.getstisla.com/assets/modules/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://demo.getstisla.com/assets/modules/nicescroll/jquery.nicescroll.min.js"></script>
    <script src="https://demo.getstisla.com/assets/modules/moment.min.js"></script>
    <script src="https://demo.getstisla.com/assets/js/stisla.js"></script>

    <!-- JS Libraies -->
    <script src="https://demo.getstisla.com/assets/modules/jquery-pwstrength/jquery.pwstrength.min.js"></script>
    <script src="https://demo.getstisla.com/assets/modules/jquery-selectric/jquery.selectric.min.js"></script>

    <!-- Page Specific JS File -->
    <script src="https://demo.getstisla.com/assets/js/page/auth-register.js"></script>

    <!-- Template JS File -->
    <script src="https://demo.getstisla.com/assets/js/scripts.js"></script>
    <script src="https://demo.getstisla.com/assets/js/custom.js"></script>
</body>

</html>
<?php /**PATH D:\PROJEK\ASIP\resources\views/components/script.blade.php ENDPATH**/ ?>